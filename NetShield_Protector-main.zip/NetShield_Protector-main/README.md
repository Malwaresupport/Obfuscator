# NetShield Protector
.NET Copy Protection Software which includes licensing your C# with many things such as Hardware ID, License, USB Hardware ID, etc....
# Obfuscastion
Base64 String Encoding.

Anti-De4dot.

Fake Obfuscastor Attributes.

Junk Methods and namespaces.

Control Flow Obfuscastion.

INT Confusion

Anti-ILDasm Protection

Renamer (renames methods, parameters, etc...)

Anti-VM

Anti-Debug

Anti-Decompiler

Packing (you have to select another obfuscastion option to enable)

# Licensing
Hardware ID Licensing

Just a license file

USB Hardware ID Licensing
# Note
for custom obfuscation program you can contact me on discord, Ahmed minegames#4108
# Credits

Thanks To <a href="https://github.com/Sato-Isolated/MindLated">MindLated Project</a> for Control Flow and INT Confusion
